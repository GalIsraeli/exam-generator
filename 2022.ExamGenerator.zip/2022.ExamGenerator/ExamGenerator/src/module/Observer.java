package module;

public interface Observer {
	void update();

}
