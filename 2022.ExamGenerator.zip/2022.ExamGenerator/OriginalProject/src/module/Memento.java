package module;

public interface Memento {

}
