package module;

public interface myCommand {
	void execute();
}
